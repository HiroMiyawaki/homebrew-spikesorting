#include "videolayout.h"
VideoLayout::VideoLayout( QWidget* parent )
    : QWidget( parent ), Ui_VideoLayout()
{
    setupUi( this );

}

