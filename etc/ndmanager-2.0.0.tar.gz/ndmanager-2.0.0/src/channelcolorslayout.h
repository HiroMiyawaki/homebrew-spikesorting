#ifndef CHANNELCOLORSLAYOUT_H
#define CHANNELCOLORSLAYOUT_H

#include "ui_channelcolorslayout.h"


class ChannelColorsLayout : public QWidget, public Ui_ChannelColorsLayout
{
    Q_OBJECT
public:
    explicit ChannelColorsLayout( QWidget* parent = 0 );
    

};

#endif
