#ifndef CHANNELOFFSETSLAYOUT_H
#define CHANNELOFFSETSLAYOUT_H

#include "ui_channeloffsetslayout.h"


class ChannelOffsetsLayout : public QWidget, public Ui_ChannelOffsetsLayout
{
    Q_OBJECT
public:
    explicit ChannelOffsetsLayout( QWidget* parent = 0 );

};

#endif
