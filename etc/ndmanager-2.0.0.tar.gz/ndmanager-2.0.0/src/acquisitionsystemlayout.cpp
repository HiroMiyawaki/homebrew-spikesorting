#include "acquisitionsystemlayout.h"

AcquisitionSystemLayout::AcquisitionSystemLayout( QWidget* parent )
    : QWidget( parent ), Ui_AcquisitionSystemLayout()
{
    setupUi( this );

}
