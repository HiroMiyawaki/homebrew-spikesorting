#include "neuroscopevideolayout.h"
NeuroscopeVideoLayout::NeuroscopeVideoLayout( QWidget* parent )
    : QWidget( parent ), Ui_NeuroscopeVideoLayout()
{
    setupUi( this );

}

