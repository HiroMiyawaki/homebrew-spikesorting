#include "lfplayout.h"
LfpLayout::LfpLayout( QWidget* parent )
    : QWidget( parent ), Ui_LfpLayout()
{
    setupUi( this );

}
