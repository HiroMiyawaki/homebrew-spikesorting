#include "clusterslayout.h"
ClustersLayout::ClustersLayout( QWidget* parent )
    : QWidget( parent ), Ui_ClustersLayout()
{
    setupUi( this );

}

