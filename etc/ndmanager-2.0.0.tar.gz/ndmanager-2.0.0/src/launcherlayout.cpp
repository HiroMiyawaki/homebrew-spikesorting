#include "launcherlayout.h"
LauncherLayout::LauncherLayout( QWidget* parent )
    : QWidget( parent ), Ui_LauncherLayout()
{
    setupUi( this );

}

