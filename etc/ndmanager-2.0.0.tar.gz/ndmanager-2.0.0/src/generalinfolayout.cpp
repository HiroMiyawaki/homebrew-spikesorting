#include "generalinfolayout.h"
GeneralInfoLayout::GeneralInfoLayout( QWidget* parent )
    : QWidget( parent ), Ui_GeneralInfoLayout()
{
    setupUi( this );

}

