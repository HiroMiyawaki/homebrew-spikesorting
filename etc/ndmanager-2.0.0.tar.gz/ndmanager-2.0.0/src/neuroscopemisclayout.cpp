#include "neuroscopemisclayout.h"
NeuroscopeMiscLayout::NeuroscopeMiscLayout( QWidget* parent )
    : QWidget( parent ), Ui_NeuroscopeMiscLayout()
{
    setupUi( this );

}
