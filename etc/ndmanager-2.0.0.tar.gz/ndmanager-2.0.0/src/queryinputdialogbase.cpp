#include "queryinputdialogbase.h"
Query::Query( QWidget* parent )
    : QWidget( parent ), Ui_Query()
{
    setupUi( this );

}

