#include "anatomylayout.h"
AnatomyLayout::AnatomyLayout( QWidget* parent )
    : QWidget( parent ), Ui_AnatomyLayout()
{
    setupUi( this );

}
