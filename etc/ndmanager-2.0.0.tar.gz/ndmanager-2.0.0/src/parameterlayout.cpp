#include "parameterlayout.h"
ParameterLayout::ParameterLayout( QWidget* parent )
    : QWidget( parent ), Ui_ParameterLayout()
{
    setupUi( this );

}

