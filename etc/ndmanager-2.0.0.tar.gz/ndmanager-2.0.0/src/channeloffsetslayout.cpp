#include "channeloffsetslayout.h"
ChannelOffsetsLayout::ChannelOffsetsLayout( QWidget* parent )
    : QWidget( parent ), Ui_ChannelOffsetsLayout()
{
    setupUi( this );

}

