#ifndef NEUROSCOPEMISCLAYOUT_H
#define NEUROSCOPEMISCLAYOUT_H

#include "ui_neuroscopemisclayout.h"


class NeuroscopeMiscLayout : public QWidget, public Ui_NeuroscopeMiscLayout
{
    Q_OBJECT

public:
    explicit NeuroscopeMiscLayout( QWidget* parent = 0 );

};

#endif
