#include "spikelayout.h"
SpikeLayout::SpikeLayout( QWidget* parent )
    : QWidget( parent ), Ui_SpikeLayout()
{
    setupUi( this );

}

