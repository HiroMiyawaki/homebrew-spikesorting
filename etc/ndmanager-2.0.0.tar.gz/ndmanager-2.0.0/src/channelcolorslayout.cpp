#include "channelcolorslayout.h"
ChannelColorsLayout::ChannelColorsLayout( QWidget* parent )
    : QWidget( parent ), Ui_ChannelColorsLayout()
{
    setupUi( this );

}

