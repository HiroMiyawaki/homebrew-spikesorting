#ifndef ACQUISITIONSYSTEMLAYOUT_H
#define ACQUISITIONSYSTEMLAYOUT_H

#include "ui_acquisitionsystemlayout.h"


class AcquisitionSystemLayout : public QWidget, public Ui_AcquisitionSystemLayout
{
    Q_OBJECT

public:
    explicit AcquisitionSystemLayout( QWidget* parent = 0 );

};

#endif
