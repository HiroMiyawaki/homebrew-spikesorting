#include "filelayout.h"
FileLayout::FileLayout( QWidget* parent )
    : QWidget( parent ), Ui_FileLayout()
{
    setupUi( this );

}

